/**
 * Some multiline comment
 */

// some other comment here