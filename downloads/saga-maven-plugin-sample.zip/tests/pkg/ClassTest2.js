new Class(false).data.getsCalledOnTheSecondRun();
new Class({}).data.getsCalledOnTheSecondRun();