function a() {
    return 0;
}

